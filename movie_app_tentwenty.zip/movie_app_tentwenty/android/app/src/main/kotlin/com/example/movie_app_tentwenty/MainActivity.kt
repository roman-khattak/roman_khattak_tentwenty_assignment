package com.example.movie_app_tentwenty

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
